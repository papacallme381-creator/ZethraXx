# ZethraX — Cloudflare Pages store starter

A lightweight, mobile-first e-commerce starter for ZethraX. Frontend: HTML/CSS/vanilla JS. Backend: Cloudflare Pages Functions. Database: Cloudflare D1. It is intentionally low-cost and avoids a paid commerce platform.

## Important launch status

This is a working starter storefront and order-management foundation, **not yet a fully operational dropshipping business**. The 20 catalogue entries are demonstration placeholders with illustrative prices, stock counts and descriptions. They are not verified supplier offers and must not be advertised as available until the owner has sourced, sampled and verified each product. The initial checkout accepts Cash on Delivery order requests only. Razorpay is a planned integration point, not enabled in this release. Supplier sourcing, courier account, final return/shipping policies, email notifications and payment credentials remain owner tasks.

## Requirements

- Cloudflare account
- Node.js LTS and npm
- Wrangler CLI (installed via this project's dev dependency)
- A Cloudflare Pages project
- A Cloudflare D1 database

## 1. Install and create D1 database

```bash
npm install
npx wrangler login
npx wrangler d1 create zethrax-db
```

Copy the `database_id` returned by Wrangler into `wrangler.toml`, replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`.

Initialize local and remote schemas:

```bash
npm run db:init
npm run db:remote
```

The schema seeds 20 sample products. Review and replace these entries before launch.

## 2. Configure local secrets

Copy `.dev.vars.example` to `.dev.vars` and set strong unique values:

- `ADMIN_PASSWORD`: long unique admin password (use a password manager)
- `SESSION_SECRET`: at least 32 random characters
- Razorpay values can remain blank until the integration is completed and tested.

Never commit `.dev.vars`, API secrets, private keys or customer data. `.gitignore` excludes it.

## 3. Run locally

```bash
npm run dev
```

Open the local URL Wrangler prints. Test the storefront, COD order creation, tracking and admin. Local Pages Functions require D1 local configuration.

## 4. Deploy to Cloudflare Pages

Recommended: connect a private GitHub repository to Cloudflare Pages.

- Framework preset: None
- Build command: leave blank (static assets are already in `public/`)
- Build output directory: `public`
- Root directory: `/`

Alternatively:

```bash
npx wrangler pages project create zethrax-store
npx wrangler pages deploy public --project-name zethrax-store
```

In Cloudflare dashboard, open Workers & Pages → zethrax-store → Settings → Functions → D1 database bindings. Add binding `DB` and select `zethrax-db` for production. Add the same binding to Preview only if you intend to test preview deployments.

Under Settings → Variables and Secrets, add:

- `ADMIN_PASSWORD` (Secret)
- `SESSION_SECRET` (Secret)
- Optional later: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` (Secrets)

Redeploy after adding bindings/secrets. Confirm the `wrangler.toml` database ID is correct.

## 5. Admin

Visit `/admin.html`. The admin password is the `ADMIN_PASSWORD` secret. Admin session cookies are HttpOnly, Secure and SameSite=Strict, and expire after 8 hours. Use HTTPS (Cloudflare Pages provides it). Do not share the admin URL/password. This initial dashboard supports listing orders, changing order status, adding products and changing price/stock/active status.

## 6. Order workflow

1. Customer submits COD order request.
2. Backend validates customer details, product IDs, quantity and stock using D1 records (not browser-submitted prices).
3. Backend saves order and reserves/decrements the sample stock.
4. Store owner checks the order in `/admin.html`, contacts the customer and confirms supplier availability, shipping charge and delivery estimate.
5. Owner fulfils manually with a verified supplier and updates status.

The storefront currently sets shipping to ₹0 in the order database. Change this before launch to a real shipping calculation or quote/confirmation workflow. Do not treat an order request as confirmed dispatch.

## 7. Payment gateway

The UI includes a disabled-by-design Razorpay choice that explains online payments are not enabled. To activate online payment, implement server-side Razorpay order creation and signature verification, persist payment IDs/status, add webhook verification, test refunds/failure flows and only then expose the option. Never put `RAZORPAY_KEY_SECRET` in browser code. Obtain gateway approval and complete KYC/business requirements directly with the payment provider.

## 8. Email, newsletter and notifications

Newsletter addresses are stored in D1; no marketing email is sent by this starter. Order confirmation emails and admin alerts are not yet configured. Choose an email service, verify the sending domain, add server-side API credentials as Cloudflare Secrets, implement unsubscribe/consent handling and test delivery before promising email notifications.

## 9. Images and products

Use optimized WebP/AVIF product images you own or are licensed to use. Replace `/assets/product-placeholder.svg` and product image paths in D1. For larger catalogues, use Cloudflare R2 with public custom-domain delivery. Confirm supplier image rights and accurate product specs. Do not use fabricated reviews or ratings; review submission/approval UI is not included yet.

## 10. Pre-launch checklist

- [ ] Verify business identity, tax obligations, consumer-protection and privacy compliance with a qualified Indian professional.
- [ ] Source suppliers; verify GST/invoices, return address, dispatch SLA, stock sync, packaging, product authenticity, warranties and reverse logistics.
- [ ] Order and inspect samples, especially electronics, cosmetics, toys, automotive and products with safety requirements.
- [ ] Replace every demo product, price, stock value and placeholder image.
- [ ] Set real shipping rates and PIN-code serviceability. Current shipping is zero in the prototype.
- [ ] Finalize transparent shipping, cancellation, return, refund and privacy terms.
- [ ] Configure a verified business email and order notifications.
- [ ] Configure payment provider only after KYC; test payment, webhook, refund and reconciliation.
- [ ] Add abuse protection/rate limiting and backup/export process.
- [ ] Test mobile layouts, accessibility, checkout, tracking and admin on production domain.
- [ ] Add custom domain when ready; free `*.pages.dev` hostname is suitable for initial testing.

## API endpoints

- `GET /api/products` — active product catalogue
- `POST /api/orders` — create COD order request
- `POST /api/track` — lookup order by ID + checkout email
- `POST /api/newsletter` — store subscriber email
- `POST /api/admin/login` — admin login
- `POST /api/admin/logout` — clear admin session
- `GET /api/admin/orders` — list recent orders (admin)
- `PATCH /api/admin/orders` — update order status (admin)
- `GET /api/admin/products` — list products (admin)
- `POST /api/admin/products` — add product (admin)
- `PATCH /api/admin/products` — update product fields (admin)

## Known limitations to address before launch

- No automatic supplier integration or inventory sync.
- No online payment processing in this release.
- No transactional email or newsletter campaign sender.
- No customer account system, wishlist persistence, compare UI, coupon redemption, reviews UI or flash-sale scheduler yet; these were selected as desired features but are not represented as working features in this starter.
- No shipping fee calculation; prototype currently records ₹0 shipping.
- No automated GST invoice, tax calculation or courier label generation.
- Add rate limiting, monitoring, backups and security review before production use.
