export const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
export const bad=(message,status=400)=>json({error:message},status);
export const body=async req=>{try{return await req.json()}catch{return null}};
export const clean=(v,max=250)=>String(v??'').trim().slice(0,max);
export const validEmail=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
