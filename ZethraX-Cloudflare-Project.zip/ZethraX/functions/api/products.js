import {json} from './_lib/http.js';
export async function onRequestGet({env}){const {results=[]}=await env.DB.prepare('SELECT id,name,slug,description,category,price,compare_at_price,image,stock,active,featured FROM products WHERE active=1 ORDER BY featured DESC, created_at DESC').all();return json(results.map(p=>({...p,active:Number(p.active),featured:Number(p.featured)})))}
