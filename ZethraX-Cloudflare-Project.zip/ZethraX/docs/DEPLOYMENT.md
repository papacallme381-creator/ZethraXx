# Cloudflare Pages deployment quick guide

1. Create a D1 database: `npx wrangler d1 create zethrax-db`.
2. Put the returned database ID into `wrangler.toml`.
3. Run `npm run db:remote` to create tables and insert the initial sample catalogue.
4. Push this project to a private GitHub repository.
5. Create a Pages project from that repository. Build command blank; output directory `public`.
6. Bind D1 as `DB` in Pages → Settings → Functions.
7. Add `ADMIN_PASSWORD` and `SESSION_SECRET` as encrypted secrets.
8. Redeploy, then test `/`, `/admin.html`, a COD test order and `/track.html`.
9. Replace all sample products and policies before advertising or taking live orders.

Use `wrangler.toml` for local Wrangler configuration. Dashboard bindings/secrets must be configured for production too.
