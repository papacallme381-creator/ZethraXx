# ZethraX manual operations

## Before accepting orders
- Confirm supplier identity, business details, GST/invoice process and product authenticity.
- Verify samples, specifications, images, warranty, safety certifications and stock.
- Agree dispatch SLA, packing, tracking, damaged-item handling, returns and refunds in writing.
- Confirm courier serviceability and actual shipping charges for customer PIN codes.

## Each order
- Review new order in Admin dashboard.
- Contact customer to confirm item, address, availability, shipping and delivery estimate.
- Confirm COD serviceability and any courier restrictions.
- Place supplier order only after verification.
- Update status: confirmed → processing → shipped → delivered (or cancelled).
- Handle customer data securely; do not export/share it unnecessarily.

## Incident handling
- For out-of-stock items, contact customer before substituting or cancelling.
- Record customer consent for any agreed change.
- Escalate damaged/incorrect parcel issues to supplier/courier and follow the published policy.
