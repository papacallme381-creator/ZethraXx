PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '',
 category TEXT NOT NULL, price INTEGER NOT NULL CHECK(price >= 0), compare_at_price INTEGER,
 image TEXT NOT NULL DEFAULT '/assets/product-placeholder.svg', stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
 address TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL, pincode TEXT NOT NULL,
 items_json TEXT NOT NULL, subtotal INTEGER NOT NULL, shipping INTEGER NOT NULL DEFAULT 0,
 total INTEGER NOT NULL, payment_method TEXT NOT NULL, payment_status TEXT NOT NULL DEFAULT 'pending',
 order_status TEXT NOT NULL DEFAULT 'placed', notes TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS subscribers (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id TEXT NOT NULL, customer_name TEXT NOT NULL, rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), review TEXT NOT NULL, approved INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE IF NOT EXISTS coupons (code TEXT PRIMARY KEY, discount_percent INTEGER NOT NULL CHECK(discount_percent BETWEEN 1 AND 90), active INTEGER NOT NULL DEFAULT 1, expires_at TEXT);
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, event_name TEXT NOT NULL, page TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
INSERT OR IGNORE INTO products (id,name,slug,description,category,price,compare_at_price,stock,featured) VALUES
('zx-001','Aura Wireless Earbuds','aura-wireless-earbuds','Everyday wireless audio with a clean, compact design. Product specifications and supplier details must be verified before sale.','Electronics & Gadgets',1299,1799,10,1),
('zx-002','FlexCharge 3-in-1 Cable','flexcharge-3-in-1-cable','A versatile charging cable concept for compatible devices. Confirm connector compatibility with supplier.','Electronics & Gadgets',399,599,15,1),
('zx-003','Minimalist Everyday Backpack','minimalist-everyday-backpack','A practical everyday carry concept with a clean silhouette. Verify dimensions and material.','Fashion & Accessories',999,1399,8,1),
('zx-004','Glow Desk Lamp','glow-desk-lamp','A modern desk-lighting pick for workspaces. Confirm electrical certification and plug type.','Home & Living',899,1199,7,1),
('zx-005','Travel Organiser Set','travel-organiser-set','A compact organiser set concept for travel essentials.','Travel Accessories',549,799,12,1),
('zx-006','Resistance Band Set','resistance-band-set','A home-workout accessory concept. Check resistance ratings and material quality.','Fitness & Lifestyle',499,699,10,0),
('zx-007','Smartphone Stand','smartphone-stand','An adjustable stand concept for desks and video calls.','Electronics & Gadgets',299,449,20,0),
('zx-008','Insulated Bottle','insulated-bottle','A reusable bottle concept for everyday hydration. Verify capacity and food-contact safety.','Home & Living',699,999,9,0),
('zx-009','Classic Crossbody Bag','classic-crossbody-bag','A versatile accessory concept for daily use.','Fashion & Accessories',799,1099,6,0),
('zx-010','LED Closet Light','led-closet-light','A compact lighting concept for wardrobes and cabinets. Verify battery and safety details.','Home & Living',349,499,14,0),
('zx-011','Gentle Face Roller','gentle-face-roller','A personal-care accessory. Avoid medical or therapeutic claims.','Beauty & Personal Care',299,449,11,0),
('zx-012','Kids Creative Art Kit','kids-creative-art-kit','A creative activity kit concept. Confirm age grading and applicable safety standards.','Kids & Toys',599,849,5,0),
('zx-013','Car Seat Gap Organiser','car-seat-gap-organiser','A vehicle storage accessory concept. Check dimensions and vehicle compatibility.','Automotive Accessories',449,649,10,0),
('zx-014','Reusable Cable Ties','reusable-cable-ties','A simple cable-management accessory for home and office.','Electronics & Gadgets',199,299,25,0),
('zx-015','A5 Premium Notebook','a5-premium-notebook','A minimal notebook concept for notes and planning.','Stationery & Books',249,349,30,0),
('zx-016','Packing Cube Trio','packing-cube-trio','A three-piece packing organiser concept. Verify exact set contents.','Travel Accessories',649,899,8,0),
('zx-017','Everyday Cap','everyday-cap','A casual accessory concept. Confirm sizing and fabric composition.','Fashion & Accessories',399,599,12,0),
('zx-018','Laptop Cleaning Kit','laptop-cleaning-kit','A cleaning accessory kit concept. Confirm safe use instructions for screens and devices.','Electronics & Gadgets',349,499,16,0),
('zx-019','Drawer Divider Set','drawer-divider-set','A home organisation accessory concept. Verify dimensions and included quantity.','Home & Living',499,749,9,0),
('zx-020','Compact Wallet','compact-wallet','A minimalist everyday wallet concept. Verify material and dimensions.','Fashion & Accessories',599,849,10,0);
